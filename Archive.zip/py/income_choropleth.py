# py/income_choropleth.py

import folium
import pandas as pd
import geopandas as gpd
from utils.html_postprocess import fix_html_metadata

def plot_income_choropleth():
    df = pd.read_csv("data/neighborhood_income_centroids.csv")
    sf_geo = gpd.read_file("data/SF_Find_Neighborhoods_2025.geojson")

    sf_geo = sf_geo.merge(df, left_on='name', right_on='neighborhood')

    m = folium.Map(location=[37.76, -122.44], zoom_start=12, tiles="CartoDB positron")

    folium.Choropleth(
        geo_data=sf_geo,
        data=sf_geo,
        columns=["neighborhood", "income"],
        key_on="feature.properties.neighborhood",
        fill_color="YlGnBu",
        fill_opacity=0.7,
        line_opacity=0.3,
        line_color="gray",
        legend_name="Average Income ($)"
    ).add_to(m)

    folium.GeoJson(
        sf_geo,
        tooltip=folium.GeoJsonTooltip(
            fields=["neighborhood", "income"],
            aliases=["Neighborhood", "Income ($)"],
            localize=True,
            sticky=False,
            labels=True,
            style="background-color: white; color: #333; font-size: 12px; padding: 6px;"
        )
    ).add_to(m)

    output_path = "outputs/income_choropleth.html"
    m.save(output_path)
    fix_html_metadata(output_path, title_text="Income Choropleth – 311 Explorer")

    return output_path
