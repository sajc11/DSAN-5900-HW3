import pandas as pd
import altair as alt
from utils.html_postprocess import fix_html_metadata

def plot_income_dot_map():
    df = pd.read_csv("data/neighborhood_income_centroids.csv")

    chart = alt.Chart(df).mark_circle(size=150).encode(
        longitude='longitude:Q',
        latitude='latitude:Q',
        color=alt.Color('income:Q', scale=alt.Scale(scheme='blues'), title='Average Income'),
        tooltip=[
            alt.Tooltip('neighborhood:N', title='Neighborhood'),
            alt.Tooltip('income:Q', format='$,.0f', title='Avg Income')
        ]
    ).properties(
        title='San Francisco Neighborhoods — Avg. Income (Centroid Map)',
        width='container',
        height=500
    ).project(
        type='mercator'
    ).configure_view(
        stroke=None
    ).configure_title(
        fontSize=16,
        anchor='start'
    )

    html_path = "outputs/income_dot_map.html"
    chart.save(html_path)
    fix_html_metadata(html_path, "Income Dot Map – 311 Explorer")

    return chart
